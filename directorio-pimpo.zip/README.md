# Directorio Pimpo
Sitio web de referencia jurídica y laboral construido con HTML estático.